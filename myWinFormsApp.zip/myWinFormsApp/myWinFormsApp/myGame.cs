﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myWinFormsApp
{
    public class myGame
    {
        string[] Symbols;
        private const string Empty = "_";

        public myGame(){            
            Symbols = new string[4];
            Clear();
        }

        private bool Check(string str, string c)
        {
            return str.Contains(c);
        }

        public bool WinCheck()
        {
            return !Symbols[0].Contains(Empty) && !Symbols[1].Contains(Empty) && !Symbols[2].Contains(Empty) && !Symbols[3].Contains(Empty);
        }

        public bool TryAdd(int line, int pos, string s)
        {
            string Raw = Symbols[line];
            string Col = Symbols[0].ToCharArray()[pos].ToString() + Symbols[1].ToCharArray()[pos].ToString() + Symbols[2].ToCharArray()[pos].ToString() + Symbols[3].ToCharArray()[pos].ToString();
            
            if (! Check(Raw, s) && ! Check(Col, s))
            {
                StringBuilder sb = new StringBuilder(Symbols[line]);
                sb[pos] = s.ToCharArray()[0];
                Symbols[line] = sb.ToString();

                return true;
            }
            return false;
        }

        public void Clear() 
        {
            for (int i = 0; i < 4; i++)
            {
                Symbols[i] = "____";
            }
        }

    }
}
