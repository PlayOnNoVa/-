﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class GameField : Form
    {
        public myWinFormsApp.myGame my;
        public GameField()
        {
            InitializeComponent();
            my = new myWinFormsApp.myGame();
        }

        private void radioButtonZ_CheckedChanged(object sender, EventArgs e)
        {
            smbAction.Text = " ";
        }

        private void radioButtonA_CheckedChanged(object sender, EventArgs e)
        {
            smbAction.Text = " ";
            if (radioButtonA.Checked) smbAction.Text = "A";
        }

        private void radioButtonB_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonB.Checked) smbAction.Text = "B";
        }

        private void radioButtonC_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonC.Checked) smbAction.Text = "C";
        }

        private void radioButtonD_CheckedChanged(object sender, EventArgs e)
        {           
            if (radioButtonD.Checked) smbAction.Text = "D";
        }

        private void smb01_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(0, 1, smbAction.Text))
            {
                smb01.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb02_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(0, 2, smbAction.Text))
            {
                smb02.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb03_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(0, 3, smbAction.Text))
            {
                smb03.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb10_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(1, 0, smbAction.Text))
            {
                smb10.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb11_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(1, 1, smbAction.Text))
            {
                smb11.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb23_Click(object sender, EventArgs e)
        {
            smb23.Text = smbAction.Text;
            if (my.TryAdd(2, 3, smbAction.Text))
            {
                smb23.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb13_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(1, 3, smbAction.Text))
            {
                smb13.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb12_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(1, 2, smbAction.Text))
            {
                smb12.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb20_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(2, 0, smbAction.Text))
            {
                smb20.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb21_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(2, 1, smbAction.Text))
            {
                smb21.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb22_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(2, 2, smbAction.Text))
            {
                smb22.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb30_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(3, 0, smbAction.Text))
            {
                smb30.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb31_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(3, 1, smbAction.Text))
            {
                smb31.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb32_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(3, 2, smbAction.Text))
            {
                smb32.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb33_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(3, 3, smbAction.Text))
            {
                smb33.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();
        }

        private void smb00_Click(object sender, EventArgs e)
        {
            if (my.TryAdd(0, 0, smbAction.Text))
            {
                smb00.Text = smbAction.Text;
            }
            lbStatus.Visible = my.WinCheck();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            my.Clear();
            smb00.Text = " "; smb01.Text = " "; smb02.Text = " "; smb03.Text = " ";
            smb10.Text = " "; smb11.Text = " "; smb12.Text = " "; smb13.Text = " ";
            smb20.Text = " "; smb21.Text = " "; smb22.Text = " "; smb23.Text = " ";
            smb30.Text = " "; smb31.Text = " "; smb32.Text = " "; smb33.Text = " ";
            lbStatus.Visible = false;
        }

      }
}
