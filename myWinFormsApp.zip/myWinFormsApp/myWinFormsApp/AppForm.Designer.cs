﻿namespace WindowsFormsApplication1
{
    partial class GameField
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameField));
            this.smb00 = new System.Windows.Forms.Button();
            this.smb01 = new System.Windows.Forms.Button();
            this.smb02 = new System.Windows.Forms.Button();
            this.smb03 = new System.Windows.Forms.Button();
            this.smb13 = new System.Windows.Forms.Button();
            this.smb12 = new System.Windows.Forms.Button();
            this.smb11 = new System.Windows.Forms.Button();
            this.smb10 = new System.Windows.Forms.Button();
            this.smb23 = new System.Windows.Forms.Button();
            this.smb22 = new System.Windows.Forms.Button();
            this.smb21 = new System.Windows.Forms.Button();
            this.smb20 = new System.Windows.Forms.Button();
            this.smb33 = new System.Windows.Forms.Button();
            this.smb32 = new System.Windows.Forms.Button();
            this.smb31 = new System.Windows.Forms.Button();
            this.smb30 = new System.Windows.Forms.Button();
            this.radioButtonD = new System.Windows.Forms.RadioButton();
            this.radioButtonC = new System.Windows.Forms.RadioButton();
            this.radioButtonB = new System.Windows.Forms.RadioButton();
            this.radioButtonA = new System.Windows.Forms.RadioButton();
            this.smbAction = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // smb00
            // 
            this.smb00.Location = new System.Drawing.Point(40, 39);
            this.smb00.Name = "smb00";
            this.smb00.Size = new System.Drawing.Size(28, 26);
            this.smb00.TabIndex = 0;
            this.smb00.UseVisualStyleBackColor = true;
            this.smb00.Click += new System.EventHandler(this.smb00_Click);
            // 
            // smb01
            // 
            this.smb01.Location = new System.Drawing.Point(74, 39);
            this.smb01.Name = "smb01";
            this.smb01.Size = new System.Drawing.Size(28, 26);
            this.smb01.TabIndex = 1;
            this.smb01.UseVisualStyleBackColor = true;
            this.smb01.Click += new System.EventHandler(this.smb01_Click);
            // 
            // smb02
            // 
            this.smb02.Location = new System.Drawing.Point(108, 39);
            this.smb02.Name = "smb02";
            this.smb02.Size = new System.Drawing.Size(28, 26);
            this.smb02.TabIndex = 2;
            this.smb02.UseVisualStyleBackColor = true;
            this.smb02.Click += new System.EventHandler(this.smb02_Click);
            // 
            // smb03
            // 
            this.smb03.Location = new System.Drawing.Point(142, 39);
            this.smb03.Name = "smb03";
            this.smb03.Size = new System.Drawing.Size(28, 26);
            this.smb03.TabIndex = 3;
            this.smb03.UseVisualStyleBackColor = true;
            this.smb03.Click += new System.EventHandler(this.smb03_Click);
            // 
            // smb13
            // 
            this.smb13.Location = new System.Drawing.Point(142, 71);
            this.smb13.Name = "smb13";
            this.smb13.Size = new System.Drawing.Size(28, 26);
            this.smb13.TabIndex = 7;
            this.smb13.UseVisualStyleBackColor = true;
            this.smb13.Click += new System.EventHandler(this.smb13_Click);
            // 
            // smb12
            // 
            this.smb12.Location = new System.Drawing.Point(108, 71);
            this.smb12.Name = "smb12";
            this.smb12.Size = new System.Drawing.Size(28, 26);
            this.smb12.TabIndex = 6;
            this.smb12.UseVisualStyleBackColor = true;
            this.smb12.Click += new System.EventHandler(this.smb12_Click);
            // 
            // smb11
            // 
            this.smb11.Location = new System.Drawing.Point(74, 71);
            this.smb11.Name = "smb11";
            this.smb11.Size = new System.Drawing.Size(28, 26);
            this.smb11.TabIndex = 5;
            this.smb11.UseVisualStyleBackColor = true;
            this.smb11.Click += new System.EventHandler(this.smb11_Click);
            // 
            // smb10
            // 
            this.smb10.Location = new System.Drawing.Point(40, 71);
            this.smb10.Name = "smb10";
            this.smb10.Size = new System.Drawing.Size(28, 26);
            this.smb10.TabIndex = 4;
            this.smb10.UseVisualStyleBackColor = true;
            this.smb10.Click += new System.EventHandler(this.smb10_Click);
            // 
            // smb23
            // 
            this.smb23.Location = new System.Drawing.Point(142, 103);
            this.smb23.Name = "smb23";
            this.smb23.Size = new System.Drawing.Size(28, 26);
            this.smb23.TabIndex = 11;
            this.smb23.UseVisualStyleBackColor = true;
            this.smb23.Click += new System.EventHandler(this.smb23_Click);
            // 
            // smb22
            // 
            this.smb22.Location = new System.Drawing.Point(108, 103);
            this.smb22.Name = "smb22";
            this.smb22.Size = new System.Drawing.Size(28, 26);
            this.smb22.TabIndex = 10;
            this.smb22.UseVisualStyleBackColor = true;
            this.smb22.Click += new System.EventHandler(this.smb22_Click);
            // 
            // smb21
            // 
            this.smb21.Location = new System.Drawing.Point(74, 103);
            this.smb21.Name = "smb21";
            this.smb21.Size = new System.Drawing.Size(28, 26);
            this.smb21.TabIndex = 9;
            this.smb21.UseVisualStyleBackColor = true;
            this.smb21.Click += new System.EventHandler(this.smb21_Click);
            // 
            // smb20
            // 
            this.smb20.Location = new System.Drawing.Point(40, 103);
            this.smb20.Name = "smb20";
            this.smb20.Size = new System.Drawing.Size(28, 26);
            this.smb20.TabIndex = 8;
            this.smb20.UseVisualStyleBackColor = true;
            this.smb20.Click += new System.EventHandler(this.smb20_Click);
            // 
            // smb33
            // 
            this.smb33.Location = new System.Drawing.Point(142, 135);
            this.smb33.Name = "smb33";
            this.smb33.Size = new System.Drawing.Size(28, 26);
            this.smb33.TabIndex = 15;
            this.smb33.UseVisualStyleBackColor = true;
            this.smb33.Click += new System.EventHandler(this.smb33_Click);
            // 
            // smb32
            // 
            this.smb32.Location = new System.Drawing.Point(108, 135);
            this.smb32.Name = "smb32";
            this.smb32.Size = new System.Drawing.Size(28, 26);
            this.smb32.TabIndex = 14;
            this.smb32.UseVisualStyleBackColor = true;
            this.smb32.Click += new System.EventHandler(this.smb32_Click);
            // 
            // smb31
            // 
            this.smb31.Location = new System.Drawing.Point(74, 135);
            this.smb31.Name = "smb31";
            this.smb31.Size = new System.Drawing.Size(28, 26);
            this.smb31.TabIndex = 13;
            this.smb31.UseVisualStyleBackColor = true;
            this.smb31.Click += new System.EventHandler(this.smb31_Click);
            // 
            // smb30
            // 
            this.smb30.Location = new System.Drawing.Point(40, 135);
            this.smb30.Name = "smb30";
            this.smb30.Size = new System.Drawing.Size(28, 26);
            this.smb30.TabIndex = 12;
            this.smb30.UseVisualStyleBackColor = true;
            this.smb30.Click += new System.EventHandler(this.smb30_Click);
            // 
            // radioButtonD
            // 
            this.radioButtonD.AutoSize = true;
            this.radioButtonD.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonD.Location = new System.Drawing.Point(146, 167);
            this.radioButtonD.Name = "radioButtonD";
            this.radioButtonD.Size = new System.Drawing.Size(33, 17);
            this.radioButtonD.TabIndex = 24;
            this.radioButtonD.Text = "D";
            this.radioButtonD.UseVisualStyleBackColor = false;
            this.radioButtonD.CheckedChanged += new System.EventHandler(this.radioButtonD_CheckedChanged);
            // 
            // radioButtonC
            // 
            this.radioButtonC.AutoSize = true;
            this.radioButtonC.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonC.Location = new System.Drawing.Point(108, 167);
            this.radioButtonC.Name = "radioButtonC";
            this.radioButtonC.Size = new System.Drawing.Size(32, 17);
            this.radioButtonC.TabIndex = 23;
            this.radioButtonC.Text = "C";
            this.radioButtonC.UseVisualStyleBackColor = false;
            this.radioButtonC.CheckedChanged += new System.EventHandler(this.radioButtonC_CheckedChanged);
            // 
            // radioButtonB
            // 
            this.radioButtonB.AutoSize = true;
            this.radioButtonB.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonB.Location = new System.Drawing.Point(74, 167);
            this.radioButtonB.Name = "radioButtonB";
            this.radioButtonB.Size = new System.Drawing.Size(32, 17);
            this.radioButtonB.TabIndex = 22;
            this.radioButtonB.Text = "B";
            this.radioButtonB.UseVisualStyleBackColor = false;
            this.radioButtonB.CheckedChanged += new System.EventHandler(this.radioButtonB_CheckedChanged);
            // 
            // radioButtonA
            // 
            this.radioButtonA.AutoSize = true;
            this.radioButtonA.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonA.Location = new System.Drawing.Point(36, 167);
            this.radioButtonA.Name = "radioButtonA";
            this.radioButtonA.Size = new System.Drawing.Size(32, 17);
            this.radioButtonA.TabIndex = 21;
            this.radioButtonA.Text = "A";
            this.radioButtonA.UseVisualStyleBackColor = false;
            this.radioButtonA.CheckedChanged += new System.EventHandler(this.radioButtonA_CheckedChanged);
            // 
            // smbAction
            // 
            this.smbAction.AutoSize = true;
            this.smbAction.BackColor = System.Drawing.Color.Transparent;
            this.smbAction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.smbAction.Location = new System.Drawing.Point(139, 9);
            this.smbAction.Name = "smbAction";
            this.smbAction.Size = new System.Drawing.Size(17, 17);
            this.smbAction.TabIndex = 23;
            this.smbAction.Text = "_";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(49, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Selected action:";
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Navy;
            this.button1.Location = new System.Drawing.Point(218, 71);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 57);
            this.button1.TabIndex = 25;
            this.button1.Text = "Нова гра";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbStatus
            // 
            this.lbStatus.BackColor = System.Drawing.Color.Transparent;
            this.lbStatus.Font = new System.Drawing.Font("Microsoft YaHei UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbStatus.ForeColor = System.Drawing.Color.Green;
            this.lbStatus.Location = new System.Drawing.Point(67, 202);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(221, 59);
            this.lbStatus.TabIndex = 26;
            this.lbStatus.Text = "Ви виграли";
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbStatus.Visible = false;
            // 
            // GameField
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(384, 288);
            this.Controls.Add(this.radioButtonD);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.radioButtonC);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.radioButtonB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioButtonA);
            this.Controls.Add(this.smbAction);
            this.Controls.Add(this.smb33);
            this.Controls.Add(this.smb32);
            this.Controls.Add(this.smb31);
            this.Controls.Add(this.smb30);
            this.Controls.Add(this.smb23);
            this.Controls.Add(this.smb22);
            this.Controls.Add(this.smb21);
            this.Controls.Add(this.smb20);
            this.Controls.Add(this.smb13);
            this.Controls.Add(this.smb12);
            this.Controls.Add(this.smb11);
            this.Controls.Add(this.smb10);
            this.Controls.Add(this.smb03);
            this.Controls.Add(this.smb02);
            this.Controls.Add(this.smb01);
            this.Controls.Add(this.smb00);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GameField";
            this.Text = "Гра 16 літер";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button smb00;
        private System.Windows.Forms.Button smb01;
        private System.Windows.Forms.Button smb02;
        private System.Windows.Forms.Button smb03;
        private System.Windows.Forms.Button smb13;
        private System.Windows.Forms.Button smb12;
        private System.Windows.Forms.Button smb11;
        private System.Windows.Forms.Button smb10;
        private System.Windows.Forms.Button smb23;
        private System.Windows.Forms.Button smb22;
        private System.Windows.Forms.Button smb21;
        private System.Windows.Forms.Button smb20;
        private System.Windows.Forms.Button smb33;
        private System.Windows.Forms.Button smb32;
        private System.Windows.Forms.Button smb31;
        private System.Windows.Forms.Button smb30;
        private System.Windows.Forms.RadioButton radioButtonD;
        private System.Windows.Forms.RadioButton radioButtonC;
        private System.Windows.Forms.RadioButton radioButtonB;
        private System.Windows.Forms.RadioButton radioButtonA;
        private System.Windows.Forms.Label smbAction;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbStatus;

    }
}

